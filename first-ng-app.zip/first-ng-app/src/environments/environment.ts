export const environment = {
  production: false,
  trackerApi: 'http://localhost:3000/log-error'
};
