import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../services/api.service';
import { TrackerService } from '../services/tracker.service';

@Component({
  selector: 'app-test-error',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './test-error.component.html',
  styleUrls: ['./test-error.component.scss'],
})
export class TestErrorComponent {
  responseData: any;
  errorMessage: string = '';

  constructor(private api: ApiService, private tracker: TrackerService) {}

  triggerError(): void {
    this.api.getData().subscribe({
      next: (res: any) => {
        this.responseData = res;
      },
      error: (err: any) => {
        this.errorMessage = 'Error caught in component.';
        console.warn('Component-level error:', err);

        // Manually track the error using TrackIt
        this.tracker.trackError(err, '/test-error');
      }
    });
  }
}
