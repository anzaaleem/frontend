import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';

export interface IErrorLog {
  message: string;
  stack_trace: string;
  route: string;
  user_agent: string;
  referer: string;
  method: string;
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class TrackerService {

  private apiEndpoint: string; // ✅ Declare the missing property

  constructor(private http: HttpClient) {
    this.apiEndpoint = environment.trackerApi; // ✅ Assign environment variable
  }

  /**
   * Main function to track and send error logs to the backend
   */
  public trackError(error: Error | any, route: string): void {
    const payload: IErrorLog = {
      message: this.getErrorMessage(error),
      stack_trace: this.getStackTrace(error),
      route: route,
      user_agent: navigator.userAgent,
      referer: document.referrer || '',
      method: 'POST',
      timestamp: new Date().toISOString()
    };

    this.sendErrorToServer(payload);
  }

  private getErrorMessage(error: any): string {
    if (error instanceof Error) {
      return error.message;
    } else if (error instanceof Object && error.error?.message) {
      return error.error.message;
    } else {
      return 'Unknown error';
    }
  }

  private getStackTrace(error: any): string {
    return error?.stack || JSON.stringify(error);
  }

  private sendErrorToServer(log: IErrorLog): void {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    this.http.post(this.apiEndpoint, log, { headers }).subscribe({
      next: () => {
        console.log('TrackerService: Error sent successfully.');
      },
      error: (err) => {
        console.error('TrackerService: Failed to send error log', err);
      }
    });
  }
}
